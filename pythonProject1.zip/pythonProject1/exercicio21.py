senhaSecreta = 8875
tentativas = 0
senha = int(input("digite sua senha  "))
tentativas =1
while tentativas <3:
    if senha != senhaSecreta:
       senha = int(input("senha errrada, digite sua senha novamente  "))
       tentativas +=1
    else:
        print("login efetuado")
        tentativas = 3
    if tentativas == 3 and senha != senhaSecreta:
        print("senha bloqueada")