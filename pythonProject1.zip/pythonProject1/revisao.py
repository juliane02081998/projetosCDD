soma = 0
for x in range(4):
    n = float(input("digite um numero  "))
    soma = soma + n
media = soma/4
print(f"o resultado da media é {media} e as somas sao {soma}")
