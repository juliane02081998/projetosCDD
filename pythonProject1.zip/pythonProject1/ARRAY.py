nomes = [" ", " ", " ", " ", " "]
for x in range(5):
    y = input("digite o nome do aluno:  ")
    nomes[x] = y
print(nomes)