nomes = [" ", " ", " ", " ", " "]
for x in range(5):
    y = input("digite o nome do aluno:  ")
    nomes[x] = y
for z in range(5):
    print(f" o aluno {nomes[z]}, esta na posição {z}")