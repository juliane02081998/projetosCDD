idade = int(input(" digite sua idade  "))
mesNasc = int(input(" digite o mes  "))
diaNasc = int(input(" digite o dia  "))
ano = 365
mes = 12
dia = 30
calculo = idade*mesNasc*diaNasc

print(f" voce tem {calculo} dias vivido ")
