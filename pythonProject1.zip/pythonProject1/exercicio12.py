# dados os valores de horarios baixo, decifre a logica e faça
# um codigo para exercutar
# entrada01 3:45
# entrada02 14:20
# saida 6:05

h1= int(input("digite a primeira hora  "))
min1=int(input("digite o primeiro minuto  "))
h2= int(input("digite a segunda hora "))
min2=int(input("digite o segundo minuto  "))
if h1 >12:
    h1=h1 -12
if h2 >12:
    h2=h2 -12
hora= h1+h2
if hora >12:
    hora = hora -12
minutos = min1+min2
if minutos >=60:
    minutos = minutos -60
    hora = hora +1
print(hora,minutos)





