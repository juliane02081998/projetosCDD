num = [0,0,0,0,0]
for i in range(5):
    num[i] = int(input(" digite um valor "))

for x in range(4,-1,-1):
    print(num[x])
