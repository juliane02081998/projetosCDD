nomes = [" ", " ", " ", " ", " "]
senhas =[0,0,0,0,0]
for x in range(5):
    nomes[x] = input("digite o nome do usuario:  ")
    senhas[x] = (input(" digite sua senha "))
for z in range(5):
    print(f" nome de usuário é: {nomes[z]} e a senha é : {senhas[z]}, esta na posição {z}")