horaInicial = int(input(" digite a hora inicial  "))
horaFinal = int(input(" digite a hora Final  "))
hora = 0
if horaInicial <= horaFinal:
    total = horaFinal - horaInicial
else:
    total = (24 - horaInicial)+ horaFinal
print(total)


