notas = [" ", " ", " ", " ", " "]
soma = 0
cont = 0
for x in range(5):
    notas[x] = float(input("digite a nota do aluno:  "))
for z in range(5):
    soma = soma + notas[z]
media = soma/5
for w in range(5):
    if notas[w] >= media:
        cont = cont+1
print(f"A média da turma é {media} e {cont} alunos aprovados")0000000000000000000000000000000000000000000000000000000000000000
