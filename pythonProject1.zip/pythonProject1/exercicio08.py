nota1 = float(input(" digite a primeira nota  "))
nota2 = float(input(" digite a segunda nota  "))
nota3 = float(input(" digite a terceira nota  "))
media = (nota1 + nota2 + nota3) / 3
if media >= 7:
    print(f"AEWWW APROVADO MINHA BENÇA SUA MEDIA É: {media}")
elif media <4:
    print(f"voce reprovou sua media é: {media}")
else:
    print(f"voce ficou em recuperaçao meu nobre sua media é: {media}")
