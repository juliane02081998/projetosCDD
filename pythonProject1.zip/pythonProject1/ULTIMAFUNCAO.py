def tratartexto(n):
    cont = 0
    for z in range(len(n) - 1, -1, -1):
        print(n[z], end=" ")
        if n[z] != " " and n[z] != "." and n[z] != "," and n[z] != "!":
            cont = cont+1
            n = input("digite uma frase ou texto que te motiva ")
            print(f"\n o texto tem {cont} letras ")





