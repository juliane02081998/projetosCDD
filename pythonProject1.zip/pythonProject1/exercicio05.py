numero1 = float(input("digite o primeiro número"))
numero2 = float(input("digite o segundo número"))

subtracao = numero1-numero2
divisao = numero1/numero2
soma = numero1+numero2
multiplicacao = numero1*numero2

print(f"o resultado da sua operação de subtraão é {subtracao}")
print(f"o resultado da sua operação dvisao é {divisao}")
print(f"o resultado da sua operação soma é {soma}")
print(f"o resultado da sua operação multiplicação é {multiplicacao}")
