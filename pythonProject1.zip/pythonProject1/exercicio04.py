nomeCompleto = input("digite seu nome")
nota1 = float(input("digite a primeira nota"))
nota2 = float(input("digite a segunda nota"))

media = (nota1+nota2)/2

print(nomeCompleto,media)

print(f"ola {nomeCompleto} sua média é {media}")