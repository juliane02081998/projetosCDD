#solicite um numero ao usuario e voce tera que imprimir o numero que ele escreveu inteiros ate 100

num = int(input("digite o numero: "))
for jj in range (1,num+1,1):
    print(jj, end=" \ ")