#faça um programa, com uma função que necessite de um argumento.
# A função retorna o valor de caractere "p", se seu argumento for positivo
# e N , se seu argumento for negativo e Z se o argumento for zero


menu = int(input("digite um numero "))
def argumento(menu):
    if menu <0:
        print("N")
    if menu == 0:
        print("Z")
    elif menu >0:
        print("P")
argumento(menu)
