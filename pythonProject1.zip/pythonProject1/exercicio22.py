pergunta= "s"
while pergunta == "s":
   notaUm = float(input("digite a nota 1  "))
   while notaUm <0 or notaUm >10:
    notaUm=float(input("nota invalida! digite novamente a primeira nota  "))
   notaDois = int(input("digite a nota 2  "))
   while notaDois <0 or notaDois >10:
      notaDois = float(input(" nota invalida! digite novamente a 2 nota  "))

   media = (notaUm+notaDois)/2
   print(media)
   pergunta= input(" DESEJA FAZER UM NOVO CALCULO?? DIGITE S OU N  ")





