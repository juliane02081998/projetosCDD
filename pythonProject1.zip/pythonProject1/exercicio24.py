num= int(input("digite um numero  "))
for jj in range(1,num+1):
   for y in range(1,jj+1):
    print(jj, end = " ")
