qtd_alunos = int(input( "digite a quantidade de alunos na sala: "))
soma_notas = 0
contador = 0
jj=0
while jj < qtd_alunos:
    nota= float(input( f"digite a nota do aluno: {contador +1}: "))
    soma_notas += nota

    jj=jj +1
media = soma_notas/qtd_alunos
print(f" a media das notas dos alunos é: {media}")