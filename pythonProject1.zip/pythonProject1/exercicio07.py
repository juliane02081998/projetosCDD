# receba 2 numeros do usuario e mostre ele em ordem crescente#

num1 = int(input("informe o primeiro numero: "))
num2 = int(input("informe o segundo numero: "))

if num1 == num2:
    print("os numeros são iguais")

else:
    if num1 > num2:
        print(num2, num1)
    else:
        print(num1, num2)
