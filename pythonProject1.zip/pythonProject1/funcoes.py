def palavra(texto):
    cont = 0
    y = "aeiouAEIOU"
    for x in texto:
        if x in y:
            cont = cont +1
    print(cont)
    texto = "o rato roeu a roupa do rei de Roma"
    palavra(texto)

def piramide1(num):
 for x in range(1,num+1):
    for y in range(1,x+1):
        print(x,end=" ")
    print()

def piramide2(qualquer):
 for x in range(qualquer):
  for y in range(1,x+1):
    print(y, end=" ")
  print()
 num = int(input(" digite um numero "))
 piramide2(num)

def estoque(produto, quantidade, preco, nomeProduto=None):
    total = quantidade * preco
    print(f" o produto é: {nomeProduto} e o valor total do seu estoque é {total}")
    nomeProduto = input(" digite o nome do produto ")
    quantidade = float(input("digite a quantidade do produto "))
    preco = float(input("digite o valor do produto "))
    estoque(nomeProduto,quantidade,preco)

def argumento(menu):
    if menu <0:
        print("N")
    if menu == 0:
        print("Z")
    elif menu >0:
        print("P")
    argumento(menu)

def somar2(x,y):
    return x+y

def somar3(*numeros):
    soma = 0
    for i in range (len(numeros)):
      soma = soma + numeros[i]
      return soma

def tratartexto(n):
    for x in n:
        if x not in " , !":
            cont = cont+1
            print(cont)

def tratartexto(n):
    cont = 0
    for z in range(len(n) - 1, -1, -1):
       print(n[z], end=" ")
    if n[z] != " " and n[z] != "." and n[z] != "," and n[z] != "!":
      cont = cont+1
      print(f" \n o texto tem {cont} letras ")

