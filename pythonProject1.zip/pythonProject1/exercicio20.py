n1 = float(input(" digite o primeiro numero  "))
n2 = float(input(" digite o segundo numero   "))

while n2 == 0:
    n2 = float(input(" digite o segundo numero novamente , nao pode ser zero  "))

div = n1/n2
print(f"o resultado é: {div}")


