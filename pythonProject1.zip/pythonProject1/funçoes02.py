def estoque(produto, quantidade, preco):
    total = quantidade * preco
    print(f" o produto é: {nomeProduto} e o valor total do seu estoque é {total}")
nomeProduto = input(" digite o nome do produto ")
quantidade = float(input("digite a quantidade do produto "))
preco = float(input("digite o valor do produto "))
estoque(nomeProduto,quantidade,preco)


