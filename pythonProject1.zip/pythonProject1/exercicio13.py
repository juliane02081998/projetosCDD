num = int(input("digite o numero: "))
for jj in range (1,11,1):
    res= jj * num
    print(f" {jj} x {num} = {res}")
