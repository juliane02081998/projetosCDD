class Pessoas():
    def __init__(self, nomeAluno,pesoAluno,idadeAluno,comendo=False):
        self.nome=nomeAluno
        self.peso=pesoAluno
        self.idade=idadeAluno
        self.comendo=True

    def comer(self,alimento):
        if self.comendo == False:
            print(f"{self.nome} esta comendo {alimento} ")
            self.comendo=True
        else:
         print(f" {self.nome} já estava comendo ")

    def pararComer(self):
        if self.comendo == True:
            print(f"{self.nome} parou de comer ")
            self.comendo=False


    def andar(self):
        print(f"{self.nome} esta caminhando ")

        if self.andar == False:
            print(f"{self.nome} esta andando ")
            self.andar = True
        else:
            print(f" {self.nome} já estava comendo ")
    def parardeAndar(self):

   def falar(self):
        print(f"{self.nome} esta falando ")