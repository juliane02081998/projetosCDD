contador = 0
for jj in range (10):
  num = int(input("digite um numero: "))
  if num (10 and 20):
     contador = contador +1
print(contador)