# digite um para cadastrar ou 2 para acessar.
# altere o sistema  anterior e faça um sistema de login, pedindo a senha do usuario
#e mostrando seu nome e a ,mensagem , login efetuado com sucesso.

nomes = [" ", " "," "," "," "]
senhas = [0,0,0,0,0]
menu = int(input("digite 1 para cadastrar , 2 para login ou 3 para sair "))
if menu != 3:
    usuario = input(" digite um nome de usuario ")
    print(usuario)
    senha = int(input(" diigte a senha "))



