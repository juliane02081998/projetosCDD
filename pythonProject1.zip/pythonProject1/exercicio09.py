nometime1 = input(" digite o nome do primeiro time  ")
gol1 = int(input(" digite a quantidade de gol  "))
nometime2 = input(" digite o nome do segundo time  ")
gol2 = int(input(" digite a quantidade de gol  "))

if gol1 >gol2:
    print(f" o time vencedor é: {nometime1}")
elif gol2 > gol1:
    print(f" o time vencedor é: {nometime2}")
else:
    print((f" empatou"))


