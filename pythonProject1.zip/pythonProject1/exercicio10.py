#ESCREVA UM ALGORITIMO QUE LEIA O NÚMERO DE LITROS VENDIDOS E O TIPO DE COMBUSTIVEL
# (CODIFICADO DA SEGUINTE FORMA: E-ETANOL, G- GASOLINA), CALCULE E IMPRIMA O VALOR
#A SER PAGO PELO CLIENTE SABENDO-SE QUE O PREÇO DO LITRO DA GASOLINA É 5,80 E DO LITRO DO ETANOL É 4,90#

valor_e = 4.9
valor_g = 5.8
tipo = input(" digite o tipo o combustivel E para etanol e G para gasolina ")
qtdlitros = float(input(" qual foi a quantidade de litros abastecido?  "))
if tipo == "g" or tipo == "G":
     total = qtdlitros*valor_g
     print(f"voce gastou , {total}")
elif tipo == "e" or tipo == "E":
     total= qtdlitros*valor_e
     print(f"voce gastou , {total}")
else:
     print("tipo de combustivel invalido")