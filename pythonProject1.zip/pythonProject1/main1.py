from classes import *

p1 = Pessoas("joao", 75, 35)
p1



