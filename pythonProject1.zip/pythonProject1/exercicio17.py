notas = 0
c = 0
for jj in range(10):
    n= float(input("digite uma nota:  "))
    notas=notas + n
    if n>=0 and n<=10:
        c=c +1
media = notas/c

print(f" suA MÉDIA É:  {media} ")