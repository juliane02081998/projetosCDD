def palavra(texto):
    letras = ""
    y = "abcdefghijklmnopqrstuvwxyzçABCDEFGHIJKLMNOPQRSTUVWXYZÇ"
    for x in texto:
        if x in y:
            letras += x
    letrasInvertidas = letras[::-1]
    print("Quantidade de letras encontradas:", len(letras))
    print("o texto ao contrário fica:", letrasInvertidas)
    print("o texto original é:", texto)

texto = input("Digite uma frase que te motiva: ")
palavra(texto)
