numero = int(input("diigite um numero   "))
if numero%2 ==0:
    print(f"o numero é par {numero}")
else:
    print(f"o numero é impar {numero}")