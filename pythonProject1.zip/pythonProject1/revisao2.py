tipo = 4
while tipo != 3:
    tipo = int(input(" digite 1 parea quadrado, 2 para triangulo ou 3 para sair "))
    if tipo == 1:
        base = float(input(" qual tamanho da base?  "))
        altura = float(input(" qual tamaho da altura?  "))
        calculo1 = (base * altura) / 2
        print(f"o calculo do triangulo é: , {calculo1}")
    elif tipo == 2:
        lado = float(input("qual tamanho do lado?  "))
        calculo2 = lado ** 2
        print(f" o calculo do quadrado é: , {calculo2}")
    if tipo == 3:
        print("obrigado por sua visita")

