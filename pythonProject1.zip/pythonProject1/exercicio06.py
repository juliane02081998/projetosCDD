a = 5
b = 10
print(f"A: {a},B: {b}")

c = a
a = b
b = c
print((f" A: {a},   B:{b}"))