qtdEleitores = int(input(" digite a quantidade de eleitores  "))
votoBranco = int(input("digite quantos votos brancos  "))
votoNulo = int(input(" digite quantos votos nulos  "))
votoValido = int(input(" digite quantos votos validos  "))
branco = (votoBranco/qtdEleitores)*100
nulo = (votoNulo/qtdEleitores)*100
valido = (votoValido/qtdEleitores)*100
print(f"o percentual foi de:branco {branco} % /n,nulo {nulo} % /n valido {valido} % ")
