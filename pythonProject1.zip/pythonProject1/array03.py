A = [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "]
M = [" ", " ", " ", " ", " ", " ", " ", " ", " ", " "]

for i in range(10):
    A[i] = int(input(" digite um valor "))
X = int(input(" digite o multiplicador "))
for z in range(10):
    M[z] = A[z] * X
print(A)
print(X)
print(M)


