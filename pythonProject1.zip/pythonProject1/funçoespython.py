def piramide1(num):
 for x in range(1,num+1):
    for y in range(1,x+1):
        print(x,end=" ")
    print()

def piramide2(qualquer):
 for x in range(qualquer):
  for y in range(1,x+1):
    print(y, end=" ")
  print()
num = int(input(" digite um numero "))
piramide2(num)